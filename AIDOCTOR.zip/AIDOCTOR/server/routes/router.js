const express = require('express');
const route = express.Router()

const services = require('../services/render');
const controller = require('../controller/controller');

const User = require('../model/User'); // Adjust the path as necessary


/**
 *  @description Root Route
 *  @method GET /
 *  @handler services.homeRoutes
 */
 
route.get('/', services.homeRoutes);



/**
 *  @description Update User Route
 *  @method GET /consultingroom
 *  @handler services.consultingroom
 */
route.get('/consultingroom',services.consultingroom)

/**
 *  @description Register Route
 *  @method GET /register
 *  @handler services.register
 */
route.get('/register', services.register);
// route.get('/add-user', services.add_user)

/**
 * @description Login Route
 * @method GET /login
 * @handler services.login
 */



// Route for user registration
route.post('/register', async (req, res) => {
    try {
        const newUser = await User.create(req.body);
        res.render('confirmation', { User });
        res.status(200).json({ message: 'User registered successfully check you mail ', user: newUser });
    } catch (err) {
        res.status(500).json({ message: 'Failed to register user', error: err });
    }
});
 
// // Registration route
// route.post('/register', (req, res) => {
//     const { name, email, password } = req.body;

//     // Save the user to the database (not implemented in this example)

//     // Send confirmation email
//     sendConfirmationEmail(email);

//     res.render('confirmation', { email });
// });


///if wamt some thing as api rouṭe


// // Registration route
// route.post('/register', (req, res) => {
//     const { name, email, password } = req.body;

//     // Save the user to the database (not implemented in this example)

//     // Send confirmation email
//     sendConfirmationEmail(email);

//     res.render('confirmation', { email });
// });


///if wamt some thing as api route const axios = require('axios');

// Controller methods for handling user operations
// exports.createUser = (req, res) => {
//     // Logic to create a new user
// };

// exports.findUser = (req, res) => {
//     // Logic to find users
// };

// exports.updateUser = (req, res) => {
//     // Logic to update a user
// };

// exports.deleteUser = (req, res) => {
//     // Logic to delete a user
// };

// // Controller methods for handling other functionalities like login, forgot password, etc.
// exports.login = (req, res) => {
//     // Logic for user login
// };

// exports.forgotPassword = (req, res) => {
//     // Logic for handling forgot password requests
// };

// exports.consultingRoom = (req, res) => {
//     // Logic for accessing the consulting room
// };

 


route.get('/login', services.login);
// route.get('/update-user', services.update_user)

// route. POST /login  

route.post('/login', services.login);

/**
 * @description Forget Password Route
 * @method GET /forgetPassword 
 * @handler services.forgetPassword
 */
route.get('/forgetPassword', services.forgetPassword);


/**
 *  @description Update User Route
 *  @method GET /update_register
 *  @handler services.update_register
 */
route.get('/update_register', services.update_register);


 

 
// // Email confirmation route
// route.get('/confirm', (req, res) => {
//     // Mark user's email as confirmed in the database (not implemented in this example)
//     // Redirect user to the login page
//     res.redirect('/');

//     // Add route to serve confirmation page

// });


route.get('/confirmation', (req, res) => {
    res.send(`
        <h1>User Registered Successfully</h1>
        <button onclick="window.location.href = '/'">home</button>
    `);
});

 
// API
route.post('/api/users', controller.create);
route.get('/api/users', controller.find);
route.put('/api/users/:id', controller.update);
route.delete('/api/users/:id', controller.delete);


// Additional routes for other functionalities
 
// // Assuming you have a controller function named createUser for handling user creation
// route.post('/api/users', controller.createUser);

// route.post('/forgotPassword', controller.forgotPassword);
// route.get('/consultingroom', controller.consultingRoom);

module.exports = route