// // // models/User.js
// // const mongoose = require('mongoose');

// // const userSchema = new mongoose.Schema({
// //     // Define your user schema fields here
// //     name: { type: String, required: true },
// //     email: { type: String, required: true, unique: true },
// //     // Add more fields as needed
// // });

// // const User = mongoose.model('User', userSchema);

// // module.exports = User;



// // Require necessary modules
// const mongoose = require('mongoose');

// // Define the User schema
// const userSchema = new mongoose.Schema({
//     name: {
//         type: String,
//         required: true
//     },
//     lname: {
//         type: String,
//         required: true
//     },
//     email: {
//         type: String,
//         required: true,
//         unique: true
//     },
//     password: {
//         type: String,
//         required: true
//     },
//     gender: {
//         type: String,
//         enum: ['Male', 'Female'],
//         required: true
//     },
//     createdAt: {
//         type: Date,
//         default: Date.now
//     }
// });

// // Create the User model from the schema
// const User = mongoose.model('User', userSchema);

// // Export the User model
// module.exports = User;
