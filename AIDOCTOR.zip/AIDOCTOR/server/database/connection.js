
const mongoose = require('mongoose');

// Replace 'YOUR_MONGODB_URI' with your actual MongoDB URI
const MONGO_URI = 'mongodb+srv://vivekdasari:Vivekwgs%401q23@cluster0.zfq9zcp.mongodb.net/medical-sector?retryWrites=true&w=majority&appName=Cluster0';

// Connect to MongoDB
const connectDB = async () => {
    try {
        // MongoDB connection options
        const options = {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            useFindAndModify: false,
            useCreateIndex: true
        };

        // Establish connection
        const con = await mongoose.connect(MONGO_URI, options);

        console.log(`MongoDB connected: ${con.connection.host}`);
    } catch (err) {
        console.error('MongoDB connection error:', err.message);
        process.exit(1); // Exit with failure
    }
};

module.exports = connectDB;
