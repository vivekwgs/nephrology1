
 const mongoose = require('mongoose');
const { Schema } = mongoose;

const userVerificationSchema = new Schema({
    // Define your schema fields here
    userId: {
        type: String,
         
    },
    uniqueString : {
        type: String,
         
         
    },
    expiresAt: {
        type: Date,
    },
    createdAt: {
        type: Date,
        default: Date.now,
       // default: Date.now,
       
    }
});

// Create and export the model
module.exports = mongoose.model('UserVerification', userVerificationSchema);
