// authMiddleware.js

const { verifyRecaptcha } = require('../server/utils/recaptcha'); // Import the function to verify reCAPTCHA

async function ensureAuthenticated(req, res, next) {
  // Verify reCAPTCHA
  try {
    await verifyRecaptcha(req.body['g-recaptcha-response']);
  } catch (error) {
    return res.render('register', { error: 'reCAPTCHA verification failed' });
  }

  // Check if the user is authenticated
  if (req.isAuthenticated()) {
    return next(); // User is authenticated, allow them to proceed
  }
  
  // If user is not authenticated, redirect to login page
  res.redirect('/login');
}

module.exports = ensureAuthenticated;








