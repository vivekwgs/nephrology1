


// server/utils/email.js
// const nodemailer = require('nodemailer');

// const sendConfirmationEmail = async () => {
//     // Nodemailer configuration
//     // nodemailer.createTransport()
//     const transporter = nodemailer.createTransport({
//         host: 'smtp.gmail.com',
//         service: 'gmail',
//         port: 587,
//         secure: false, // true for 465, false for other ports
//         auth: {
//             user: 'kedharnadh686@gmail.com', // replace with your email address
//             pass: 'trgmbgcvsxyajvsk' // replace with your email password
//         }
//     });

//     const mailOptions = {
//         from: 'kedharnadh686@gmail.com',
//         to: 'mounika@wgsindia.com', //mailto:vivekdasari@wgsindia.com   mailto:mounika@wgsindia.com
//         subject: 'Confirmation Email',
//         text: 'Please click the link to confirm your email address: http://example.com/confirm'
//     };
//     //transporter.sendMail()
//     // Send the email
//     transporter.sendMail(mailOptions, (error, info) => {
//         if (error) {
//             console.log(error);
//             // In this context, we cannot use `res`, as it is not defined here
//             // Instead, you should handle errors by throwing an error or returning a Promise
//             throw new Error('An error occurred while sending the email.');
//         } else {
//             console.log('Email sent: ' + info.response);
//             // Similarly, we cannot use `res` here, so you should not send a response
//             // Instead, let the calling function handle the success message
//         }
//     });
// }


// const nodemailer = require('nodemailer');
// //import { createTransport } from 'nodemailer';

// // Create a transporter object using SMTP transport
// let transporter = nodemailer.createTransport({
//     service: 'Gmail',
//     auth: {
//         user: 'kedharnadh686@gmail.com',
//         pass: 'trgmbgcvsxyajvsk'
//     }
// });

// // Setup email data
// let mailOptions = {
//     from: '"nanis" <yourEmail@gmail.com>',
//    // to: 'mounika@wgsindia.com', //mailto:mounika@wgsindia.com mounika@wgsindia.com
//     to: email,
//     subject: 'Hello from Node.js!',
//     text: 'This is a test email sent from Node.js using nodemailer.',
//     text: 'Please click the link to confirm your email address: http://example.com/'
//    // html: '<p>This is a test email sent from <b>Node.js</b> using <i>nodemailer</i>.</p>'
// };

// // Send email
// transporter.sendMail(mailOptions, (error, info) => {
//     if (error) {
//         return console.log('Error occurred:', error);
//     }
//     console.log('Message sent successfully!', info.messageId);
// });

// module.exports;



// var nodemailer = require('nodemailer');

// var transporter = nodemailer.createTransport({
//   service: 'gmail',
//   auth: {
//     user: 'kedharnadh686@gmail.com',
//     pass: 'trgmbgcvsxyajvsk'
//   }
// });

// var mailOptions = {
//   from: 'kedharnadh686@gmail.com',
//   to: email,
//   subject: 'Sending Email using Node.js',
//   text: 'That was easy!'
// };

// transporter.sendMail(mailOptions, function(error, info){
//   if (error) {
//     console.log(error);
//   } else {
//     console.log('Email sent: ' + info.response);
//   }
// });








// const express = require('express');
// const dotenv = require('dotenv');
// const morgan = require('morgan');
// const path = require('path');
// const bodyParser = require('body-parser');

// const connectDB = require('./server/database/connection');
// //const { sendConfirmationEmail } = require('./server/utils/email');
// const User = require('./models/User');  // Import your Mongoose User model



// const app = express();

// dotenv.config( { path : 'config.env'} )
// const PORT = process.env.PORT || 3000

// // log requests
// app.use(morgan('tiny'));

// // mongodb connection
// connectDB();

 
//  // parse application/x-www-form-urlencoded
// app.use(bodyParser.urlencoded({ extended: false }));

// // parse application/json
// app.use(bodyParser.json());
// app.use(express.static(__dirname + '/public'));
// // set view engine
// app.set("view engine", "ejs")
// //app.set("views", path.resolve(__dirname, "views/ejs"))

// // load assets
// app.use('/css', express.static(path.resolve(__dirname, "assets/css")))
// app.use('/img', express.static(path.resolve(__dirname, "assets/img")))
// app.use('/js', express.static(path.resolve(__dirname, "assets/js")))


// // Route to serve the login form
// app.get('/login', (req, res) => {
//     res.render('login'); // Assuming you have a login.ejs file
// });


// // Registration route
// app.post('/register', async (req, res) => {
//     // Extract user data from the request body
//     const { name, lname, email, password, reconfirmPassword, gender } = req.body;

//     try {
//         // Validate the input fields
//         if (!name || !lname || !email || !password || !reconfirmPassword || !gender) {
//             return res.status(400).send('Please fill out all the fields.');
//         }

//         // Check if passwords match
//         if (password !== reconfirmPassword) {
//             return res.status(400).send('Passwords do not match.');
//         }

//         // Save the user to the database
//         // Here, you should have the logic to save the user to your MongoDB database
//         // This would involve creating a new user document and inserting it into your User collection
//         // For simplicity, let's assume you have a User model and you can create a new user instance and save it
//         // Replace 'User' with your actual Mongoose User model
//         const newUser = new User({ name, lname, email,reconfirmPassword, password, gender });
//         await newUser.save();

//         // Send confirmation email
//        // await sendConfirmationEmail(req.body.email);

//         //render
//       res.render('confirmation', { email });
//         // Respond with a success message
//         res.status(201).send('User registered successfully.');

//     } catch (error) {
//         console.error('Error registering user:', error);
//         res.status(500).send('Error registering user.');
//     }
// });


// // Email confirmation route handler
// app.get('/confirm', (req, res) => {
//     // Here you would typically implement logic to mark the user's email as confirmed in the database
//     // This could involve updating the user's record in the database to indicate that their email is confirmed

//     // For demonstration purposes, let's assume the email is confirmed and redirect the user to the login page
//     res.redirect('/');
// });




// // load routers
// app.use('/', require('./server/routes/router'))

// app.listen(PORT, ()=> { console.log(`Server is running on http://localhost:${PORT}`)});