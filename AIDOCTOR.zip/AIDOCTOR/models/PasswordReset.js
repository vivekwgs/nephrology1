const { string } = require("joi");
const mongoose = require("mongoose");
const schema = mongoose.schema;

const passwordResetSchema = new schema ({
    userId: string,
    uniqueString: string,
    CreatedAt: Date,
    expiresAt : Date,
});

const PasswordReset = mongoose.model('PasswordReset', passwordResetSchema);

module.exports = PasswordReset;


// //reset passwod
// app.post('/forgetPassword', (req,res) => {
//     const {email,redirectUrl } = req.body;

//     //check the email exists
//     User 
//       .find ({email})
//        .then ({data}) => {
        
//        }
// })