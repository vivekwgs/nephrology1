
  const express = require('express');
  const dotenv = require('dotenv');
const morgan = require('morgan');
const path = require('path');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer'); // Import nodemailer
const app = express();
const connectDB = require('./server/database/connection');
const User = require('./models/User');

// const UserVerification = require('./models/UserVerification');


 // Load environment variables
//  dotenv.config({ path: 'config.env' });

 dotenv.config();
const PORT = process.env.PORT || 3000;
//  const {v4, uuidv4 } = require("uuid");
///const { error } = require('console');//
app.use(morgan('tiny'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(__dirname + '/public'));
   
// Set view engine and load assets
app.set("view engine", "ejs");
 

// mongodb connection
connectDB()

// After successful email verification, redirect to the login page
app.get('/login', (req, res) => {
    res.render('login'); // Render the login form
});

// // After 1 minute, redirect to the home dashboard
// setTimeout(() => {
//     app.get('/login', (req, res) => {
//         res.redirect('/home'); // Redirect to the home dashboard
//     });
// }, 60000); // 60000 milliseconds = 1 minute

const SECRET_KEY = 'your_secret_key';




// Function to generate activation token
function generateActivationToken() {
    // Generate a random token using crypto
    const token = crypto.randomBytes(20).toString('hex'); // 20 bytes will generate a 40-character hex string
    return token;
}


// Function to send activation email
async function sendActivationEmail(newUser, activationToken,verificationToken) {
    const activationLink = `${process.env.BASE_URL}/login/activate/${activationToken}`;
    const verificationLink = `${process.env.BASE_URL}/verify/${verificationToken}`;

    const mailOptions = {
        from: 'kedharnadh686@gmail.com',
        to: newUser.email,
        subject: 'Registration Confirmation',
        text: `Dear ${newUser.name},\n\nThank you for registering with us! Please click <a href="${activationLink}">click here you link </a> to verify your email.`,
        html: `<p>Click the following link to activate your account:</p><a href="${activationLink}">Activate Account</a>`,
        text: `<p>Please click <a href="${verificationLink}">here</a> to verify your email address.</p>` // HTML content with verification link
    };

    // Create nodemailer transporter
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'kedharnadh686@gmail.com', // replace with your email address
            pass: 'trgmbgcvsxyajvsk' // replace with your email password
        }
    });

    try {
        // Send the email
        const info = await transporter.sendMail(mailOptions);
        console.log('Email sent:', info.response);
    } catch (error) {
        console.log('Error sending email:', error);
        throw error; // Propagate the error to the caller
    }
}



//  reser password adn generate password token 
     // function to send reset password email 
     async function sendResetPasswordEmail(email, resetPasswordToken) {
        try {
            const transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                    user: 'kedharnadh686@gmail.com', // replace with your email address
                    pass: 'trgmbgcvsxyajvsk' // replace with your email password
                }
                 });

                //  //construct the rest password link with the token 
                //  let resetPasswordLink;
                //  if (isForgotPassword) {
                //     resetPasswordLink = `${process.env.BASE_URL}/reset-password?token=${resetPasswordToken}`;
                // } else {
                //     resetPasswordLink = `${process.env.BASE_URL}/forgot-password?token=${resetPasswordToken}`;
                //  }

                //  //compose the email 
                //  let emailSubject, emailText;
                //  if (isForgotPassword) {
                //     emailSubject = 'Forgot password Request';
                //     emailText = `Click <a href="${resetPasswordLink}">here</a> to reset your password.`;
                //  } else {
                //     emailSubject = 'Password Reset Request';
                //     emailText = `Click <a href="${resetPasswordLink}">here</a> to initiate the password reset process`;
                //  }

                const resetPasswordLink = `${process.env.BASE_URL}/reset-password?token=${resetPasswordToken}`;

                const mailOptions = {
                    from: 'kedharnadh686@gmail.com',
                    //to: newUser.email,
                    to: email, // Correct recipient's email address
                    subject: 'Password Reset Request',
                    html: `Click <a href="${resetPasswordLink}">here</a> to reset your password.`,
                };
        
                
                 
                

                  // Send the email
       
                  const info = await transporter.sendMail(mailOptions);
                  console.log('Email sent:', info.response);
        
            } catch (error) {
                console.error('Error sending email:', error);
                throw error;
            } 
         }


 // Function to generate reset password token
function generateResetPasswordToken() {
    // Generate a random token using crypto
    const resetPasswordToken = crypto.randomBytes(20).toString('hex');
    return resetPasswordToken;
}
        

app.get('/forgot-Password', (req,res) =>{
    res.render('forgot-Password');
})

app.get('/reset-password', (req,res) => {
    res.render('reset-password');
})






// Registration route - Generate activation token and send confirmation email ,gRecaptchaResponse !gRecaptchaResponse
app.post('/register', async (req, res) => {
    const { name, lname, email, password , reconfirmPassword, gender } = req.body;

    try {
        // Validation checks
        if (!name || !lname || !email || !password || !reconfirmPassword || !gender  ) {
            return res.status(400).send('Please fill out all the fields.');
        }
        if (password !== reconfirmPassword) {
            return res.status(400).send('Passwords do not match.');
        }

        // Check if the email is already registered
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'Email already exists' });
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Generate activation token
        const activationToken = generateActivationToken();
        const verificationToken = generateActivationToken();

        // Save user to the database
        const newUser = new User({
          
            name,
            lname,
            email,
            password: hashedPassword,
            activationToken,
            verificationToken,
            reconfirmPassword,
            gender,
            // gRecaptchaResponse ,
            isActivated : false,
           //isActivated, // Assuming users are not activated by default
            is_agree: 'YES'
        });
        await newUser.save();

 

        // Send activation email
        await sendActivationEmail(newUser, activationToken);

        // Render confirmation page
        res.render('confirmation', { email: newUser.email });

        // Send response
        // res.send("Registration successful. Check your email for activation link.");
    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).send('Error registering user.');
    }
});


// Express route to handle activation link
app.get('/login/activate/:activationToken', async (req, res) => {
    const activationToken = req.params.activationToken;

    var userId = req.params.userId;

    const activationLink = `${process.env.BASE_URL}/login/activate/${activationToken}`;
    // Use activationToken to retrieve user data from the database
    try {
        //find the user by activation token 
const user = await User.findOne({ activationToken });
//check if user exists
if (!user) {
   return res.status(404).send("Activation token not found or expired");

}


var isActivated = false; // Initialize isActivated with a default value

// Later in your code, update isActivated based on certain conditions


if (userId && token) {
    isActivated = true;
} else {
    isActivated = false;
}
 

activateAccount(userId);
   // Activate the user;s account 
       user.isActivated = true;
       await user.save();
       
       res.redirect('/login');


// Now you can use isActivated in your code to control certain behaviors
if (isActivated) {
    // Execute code if isActivated is true
    console.log("user is active.processd to the next page   ")
} else {
    console.log("user is not activing Access denide")
    // Execute code if isActivated is false
}


    } catch (error) {
        console.error('Error activating user:', error);
        res.status(500).send('Error activating user.');
    }

});
       


  

  
function activateAccount(userId) {
    isActivated = true;
}

app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        // Check if user exists
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Validate password
        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
            return res.status(401).json({ message: 'Invalid password' });
        }

        // Generate JWT token
        const token = jwt.sign({ email: user.email, id: user._id }, SECRET_KEY, { expiresIn: '1d' });

        res.status(200).json({ token });
    } catch (error) {
        console.error('Error logging in:', error);
        res.status(500).json({ message: 'Error logging in' });
    }
});


// Express route to handle verification token submission
app.post('/login/verify', function(req, res) {
     
    const verificationToken = req.body.verificationToken;
    // Use verificationToken to retrieve user data from the database
     // Find the user by verification token
     User.findOne({ verificationToken }, function(err, user) {
        if (err) {
            // Handle database error
            res.status(500).send("Internal Server Error");
            return;
        }
        if (!user) {
            // Verification token not found or expired
            res.status(404).send("Verification token not found or expired");
            return;
        }
        // Handle verification logic here
        // Handle verification logic here
        user.isVerified = true;
        // Save the updated user data
        user.save(function(err) {
            if (err) {
                // Handle database error
                res.status(500).send("Internal Server Error");
                return;
            }
            // Redirect user to dashboard
            res.redirect('/');
        });
    });
});

  // Protected Route Example
 

// // Token verification middleware
// function verifyToken(req, res, next) {
//     const token = req.headers.authorization;
//     if (!token) {
//         return res.status(401).json({ message: 'Token not provided' });
//     }
//     jwt.verify(token.split(' ')[1], SECRET_KEY, (err, decoded) => {
//         if (err) {
//             return res.status(401).json({ message: 'Invalid token' });
//         }
//         req.user = decoded;
//         next();
//     });
// }


// Home page route
app.get('/',   (req, res) => {
    res.send('Welcome to the home page!');
});

// Protected route example
app.get('/protected/resource', function(req, res) {
    const currentUser = req.user;
    res.json({ message: 'Access granted to protected resource', user: currentUser });
});


// Email confirmation route handler
app.get('/confirm', (req, res) => {
    // Logic to handle email confirmation (e.g., updating user's record)
    // For demo purposes, redirect to the login page
    res.redirect('/login');
});

// Load routers
app.use('/', require('./server/routes/router'));



// app.listen(PORT, () => {
//     console.log(`Server is running on http://localhost:${PORT}`);
// });


 // Route to handle forgot password request
 app.post('/forgot-password', async (req, res) => {
    const { email } = req.body;

    try {
        // Check if the email exists in the database
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Generate reset password token
        const resetPasswordToken = generateResetPasswordToken();

        // Save the reset password token to the user's document in the database
        user.resetPasswordToken = resetPasswordToken;
        await user.save();

        // Send reset password email
        await sendResetPasswordEmail(email, resetPasswordToken);

        res.status(200).json({ message: 'Reset password instructions sent to your email.' });
    } catch (error) {
        console.error('Error processing forgot password request:', error);
        res.status(500).json({ message: 'Error processing forgot password request.' });
    }
});


// Express route to handle password reset
app.post('/reset-password', async (req, res) => {
    // Extract the reset token, new password, and confirm password from the request body
    const { token, newPassword, confirmPassword } = req.body;

    try {
        // Verify if the reset token exists
        const user = await User.findOne({ resetPasswordToken: token });
        if (!user) {
            // If the token is invalid or expired, return an error response
            return res.status(400).send('Invalid or expired reset token.');
        }

        // Check if the new password matches the confirm password
        if (newPassword !== confirmPassword) {
            // If passwords do not match, return an error response
            return res.status(400).send('Passwords do not match.');
        }

        // Hash the new password
        const hashedPassword = await bcrypt.hash(newPassword, 10);

        // Update the user's password and clear the reset token
        user.password = hashedPassword;
        user.resetPasswordToken = undefined; // Clear the reset token
        await user.save();

        // Send a success response
        res.status(200).send('Password reset successful.');
    } catch (error) {
        // If an error occurs during the password reset process, log the error and return a generic error response
        console.error('Error resetting password:', error);
        res.status(500).send('Error resetting password.');
    }
});





app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});






// // Home route
// app.get('/', authenticateToken, (req, res) => {
//     // Render your home page here
//     res.redirect('/')
// });

// // Middleware to authenticate JWT token
// function authenticateToken(req, res, next) {
//     // Your authentication logic here
// }

// app.get('/verify/:verificationToken', async (req, res) => {
//     try {
//       const verificationToken = req.params.verificationToken;
//       // Find user by verification token
//       const user = await User.findOne({ verificationToken });
//       if (!user) {
//         return res.status(404).send('Verification token not found or expired.');
//       }
//       // Update user's isVerified status
//       user.isVerified = true;
//       await user.save();
//       res.redirect('/login');
//     } catch (error) {
//       console.error('Error verifying user:', error);
//       res.status(500).send('Error verifying user.');
//     }
//   });

//   async function sendVerificationEmail(email, verificationToken) {
//     const verificationLink = `${process.env.BASE_URL}/verify/${verificationToken}`;
//     // Send email with verification link
//   }

// verification token 


    // Example using MongoDB and Mongoose:
    //User.findOne({ activationToken: activationToken }, function(err, user) {
        //User.findOne({ activationToken }, function(err, user) {
        // if (err) {
        //     // Handle database error
        //     res.status(500).send("Internal Server Error");
        //     return;
        // }
        // if (!user) {
        //     // Activation token not found or expired
        //     res.status(404).send("Activation token not found or expired");
        //     return;
        // }
        // Handle activation logic here
        // Redirect user to login form or dashboard
        // user.isActivated = true;
        //sava the updated user data
        // user.save(function(err) {
            // if (err) {
            //     //handle database error
            //     res.status(500).send("Internal server errror");
            //     return;

            // }
            //redirect user to login form or dashboard
            // res.redirect('/login')
//         })
//     });
// });



// Express route to handle verification token submission

// app.post part we in uncomment in case that 9.00 pm 

// some generating 

// // Function to generate activation token
// function generateActivationToken() {
//     // Generate a random token (you can use libraries like crypto or uuid)
//     const token = 'generated_token_here';
//     return token;
// }
// // Function to send activation email
// function sendActivationEmail(email, activationToken) {
//     const activationLink = `${process.env.BASE_URL}/login/activate/${activationToken}`;
//     // Rest of your code
//     const message = `Click the following link to activate your account: ${activationLink}`;
// }


// // Registration route Registration route - Generate activation token and send confirmation email
// app.post('/register', async (req, res) => {
//     const { name, lname, email, password, reconfirmPassword, gender } = req.body;

//     try {
//         // Validation checks
//         if (!name || !lname || !email || !password || !reconfirmPassword || !gender) {
//             return res.status(400).send('Please fill out all the fields.');
//         }
//         if (password !== reconfirmPassword) {
//             return res.status(400).send('Passwords do not match.');
//         }
//          // Check if the email is already registered
//          const existingUser = await User.findOne({ email });
//          if (existingUser) {
//              return res.status(400).json({ message: 'Email already exists' });
//          }
//       // Hash the password
//       const hashedPassword = await bcrypt.hash(password, 10);
      
//    // Generate activation token
//    //const activationToken = crypto.randomBytes(20).toString('hex');
//     // Generate activation token
//     const activationToken = generateActivationToken();

//         // Save user to the database
//         const newUser = new User({  name,
//             lname,
//             email,
//             password: hashedPassword,
//             activationToken: activationToken,
//             reconfirmPassword,
//             gender,
//             is_agree: 'YES' });
//         await newUser.save()// Send activation email

//         // Function to send activation email
// function sendActivationEmail(newUser, activationToken) {

//     const activationLink = `${process.env.BASE_URL}/login/activate/${activationToken}`;
 
//     const mailOptions = {
//         from: 'kedharnadh686@gmail.com',
//         to: newUser.email,
//         subject: 'Registration Confirmation',
//         text: `
//             Dear ${newUser.name},\n\nThank you for registering with us! Please click <a href="${activationLink}">click here you link </a> to  verify your email.`,
//         html: `<p>Click the following link to activate your account:</p><a href="${activationLink}">Activate Account</a>`
       
//     };
//   //  await transporter.sendMail(mailOptions);
//  //   await transporter.sendMail(mailOptions);
//      // Send confirmation email
//      const transporter = nodemailer.createTransport({
//         service: 'gmail',
//        auth: {
//              user: 'kedharnadh686@gmail.com', // replace with your email address
//           pass: 'trgmbgcvsxyajvsk' // replace with your email password
//       }
//      });   

//     res.send('Verification email sent');
//  // alert('Verification email sent')
// // Render confirmation page after sending the email

// transporter.sendMail(mailOptions, function (error, info) {
//     if (error) {
//         console.log('Error sending email:', error);
//     } else {
//         console.log('Email sent:', info.response);
//     }
// });

// }

       
//         await sendActivationEmail(newUser, activationToken);


   
 
//         // Render confirmation page
//         res.render('confirmation', { email: newUser.email });
//         // Send response
//         res.send("Registration successful. Check your email for activation link.");
//     } catch (error) {
//         console.error('Error registering user:', error);
//         res.status(500).send('Error registering user.');
//     }
// });

       // if (result.insertedCount > 0) {
            // construct the activation link
     // Send verification email
// Send verification email


        // }

       // http://localhost:3001/login/
        // Send verification email
    // const verificationToken = jwt.sign({ email: newUser.email }, 'your_secret_key');
    // const verificationLink = `http://localhost:3001/login/verify?token=${verificationToken}`;
  // Generate verification URL
  //const verificationUrl = `${req.protocol}://${req.get('host')}/verify/${verificationToken}`;

      
 




// Activation route // Define a route handler for the activation link
// app.get('/login/activate/:activationToken', async (req, res) => {
//     try {
//         //const token = req.params.token;
//         const { activationToken } = req.params;

 
//          // Find user by activation token
//          const user = await User.findOne({ activation_token: activationToken }); // Corrected variable name

//          if (!user) {
//             return res.status(404).json({ message: 'Invalid activation token' });
//         }

//     // Update user's status to activated (for example)
//     user.isActive = true;
//     await user.save();

//         // Here, you're trying to update the user's status, but it seems the logic is incorrect.
//         // Make sure you update the correct field in the user document to mark it as activated.
//         // Also, ensure you use the correct variable for the user's email.
//       //  await User.updateOne({ _id: user._id }, { $set: { activated: true } }); // Corrected variable name


//         // Redirect user to login page or send any other response as needed
//        // res.render('login', { activationToken });
// // Redirect user to login page after activation
// res.redirect('/login');
//     } catch (error) {
//         console.error('Error:', error);
//         return res.status(500).json({ message: 'Internal server error' });
//     }
// });



// // Authentication Route
// app.post('/login', async (req, res) => {
//     try {
//         // Your login logic here
//         const { email, password } = req.body;
//         const user = await User.findOne({ email });
// // Find the user in the mock database
//    // const user = User.findOne({user => user.email === email,verified:true });
//    if (!user) {
//     return res.status(401).json({ message: 'Invalid username or password' });
//     //return res.status(401).json({ message: 'Invalid username or password' });
// }

//  // Verify the password
// //  const isPasswordValid = await bcrypt.compare(password, user.password);
// //  if (!isPasswordValid) {
// //      return res.status(401).json({ message: 'Invalid username or password' });
// //  }
// const token = jwt.sign({ id: user }, 'your_secret_key', { expiresIn: '1d' });
//     if (!user || user.password !== password) {
//         return res.status(400).send('Invaild credentials ');
        
//     }
//     res.send({ token });
//         // Upon successful login, redirect to the home page
//         // Generate a JWT token
       
//     //const token = jwt.sign({ email: user.email }, SECRET_KEY, { expiresIn: '1d' });
        

//         res.redirect('/');
//     } catch (error) {
//         res.status(500).send(error.message);
//     }
// });







//email verification route

// Email verification route
// app.get('/verify/:token', async (req, res) => {
//     try {
//         const token = req.query.token;
//         const decoded = jwt.verify(token, 'your_secret_key');
//         const userEmail = decoded.email;

//         // Update user's status to verified
//         await User.findOneAndUpdate({ email: userEmail }, { $set: { verified: true } });
//         alert("sucessfull login part ")
//         // Redirect to the login page after email verification
//         res.redirect('/login');
//     } catch (error) {
//         res.status(401).send('Invalid or expired token');
//     }
// });

// Email confirmation route
// app.get('/verify/:token', async (req, res) => {
//     try {
//         const { token } = req.params;
//         //const decoded = jwt.verify(token, 'your_secret_key');

        
//         //const userEmail = decoded.email;

//         // Update user's status to verified
//        // await User.findOneAndUpdate({ email: userEmail }, { $set: { verified: true } });
//         //res.send('Email verified successfully. <a href="/login">Click here</a> to login.');

//   // Verify token logic decoded
//   jwt.verify(token, 'your_secret_key', (err) => {
//     if (err) {
//       return res.status(401).json({ message: 'Invalid token' });
//     }
//     // Token is valid, redirect to login page
//     res.redirect('Email verified successfully. <a href="/login">Click here</a> to login.');
//   });


//     } catch (error) {
//         res.status(401).send('Invalid or expired token');
//     }
// });

// Authentication Route
//   app.post('/login', async (req, res) => {
//      try {
//         const { email, password } = req.body;

//         //check if user exists and email is verified 

//         const user = await User.findOne({ email, verified: true});

//         // Find the user in the mock database
//    // const user = User.findOne({user => user.email === email,verified:true });
//     if (!user) {
//         return res.status(401).json({ message: 'Invalid username or password' });
//         //return res.status(401).json({ message: 'Invalid username or password' });
//     }

//      // Verify the password
//      const isPasswordValid = await bcrypt.compare(password, user.password);
//      if (!isPasswordValid) {
//          return res.status(401).json({ message: 'Invalid username or password' });
//      }

//         if (!user || user.password !== password) {
//             return res.status(400).send('Invaild credentials ');
            
//         }
//         //Generate Jwt token 
//         // const token = jwt.sign({ email: user.email },
//         //     'your_secret_key');

//              // Generate a JWT token
//     const token = jwt.sign({ email: user.email }, SECRET_KEY, { expiresIn: '1d' });
//             res.send({ token });


//      } catch (error) {
//         res.status(500).send(error.message);

//      }
//   })



// Serve your React application for any request that doesn't match an API route
// app.get("*", (req, res) => {
//     res.sendFile(path.join(__dirname, "build", "index.html"));
//   });

  // Middleware to authenticate JWT token
//   function authenticateToken(req, res, next) {
//     const authHeader = req.headers['authorization'];
//     const token = authHeader && authHeader.split(' ')[1];
  
//     if (!token) return res.status(401).send('Token not provided');
  
//     jwt.verify(token, 'your_secret_key', (err, user) => {
//       if (err) return res.status(403).send('Invalid token');
//       req.user = user;
//       next();
//     });
//   }
